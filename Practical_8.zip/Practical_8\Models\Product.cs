﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Practical_8.Models
{
    public class Product
    {
        public int ProductId { get; set; }

        public string ProductName { get; set; }

        public int Quantity { get; set; }   

        public decimal Price { get; set; }


    }
}