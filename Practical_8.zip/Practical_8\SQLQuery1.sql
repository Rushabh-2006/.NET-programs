﻿CREATE TABLE Products
(
 ProductId INT PRIMARY KEY IDENTITY(1,1),
 ProductName VARCHAR(100) NOT NULL,
 Quantity INT NOT NULL,
 Price DECIMAL(10,2) NOT NULL
);
GO
INSERT INTO Products (ProductName, Quantity, Price)
VALUES
('Keyboard',20,500.00),
('Mouse',30,700.00),
('Monitor',15,25000.00),
('Printer',2,5000.00),
('Scanner',5,3000.00),
('Webcam',10,1500.00),
('Headset',25,2000.00),
('Speakers',8,3500.00),
('External Hard Drive',12,8000.00),
('USB Flash Drive',50,1000.00);
