using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartCampusPortal.Data;
using SmartCampusPortal.Models;

namespace SmartCampusPortal.Controllers
{
    public class ComplaintController : Controller
    {
        private readonly ApplicationDbContext _context;
        public ComplaintController(ApplicationDbContext context) => _context = context;

        // GET: /Complaint — shows file form + all complaints
        public async Task<IActionResult> Index()
        {
            ViewBag.Students    = await _context.Students.OrderBy(s => s.FullName).ToListAsync();
            ViewBag.Complaints  = await _context.Complaints
                                    .Include(c => c.Student)
                                    .OrderByDescending(c => c.FiledOn)
                                    .ToListAsync();
            return View(new Complaint());
        }

        // POST: /Complaint/Submit
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Submit([Bind("StudentId,Title,Description,Category")] Complaint complaint)
        {
            if (ModelState.IsValid)
            {
                complaint.FiledOn = DateTime.Now;
                complaint.Status  = ComplaintStatus.Open;
                _context.Complaints.Add(complaint);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Complaint filed successfully!";
                return RedirectToAction(nameof(Index));
            }
            TempData["Error"] = "Please fill all required fields.";
            return RedirectToAction(nameof(Index));
        }

        // POST: /Complaint/UpdateStatus
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateStatus(int id, ComplaintStatus status)
        {
            var c = await _context.Complaints.FindAsync(id);
            if (c != null)
            {
                c.Status = status;
                if (status == ComplaintStatus.Resolved) c.ResolvedOn = DateTime.Now;
                await _context.SaveChangesAsync();
                TempData["Success"] = "Complaint status updated!";
            }
            return RedirectToAction(nameof(Index));
        }

        // POST: /Complaint/Delete
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var c = await _context.Complaints.FindAsync(id);
            if (c != null) { _context.Complaints.Remove(c); await _context.SaveChangesAsync(); TempData["Success"] = "Complaint deleted."; }
            return RedirectToAction(nameof(Index));
        }
    }
}
