using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartCampusPortal.Data;
using SmartCampusPortal.Models;

namespace SmartCampusPortal.Controllers
{
    public class StudentController : Controller
    {
        private readonly ApplicationDbContext _context;
        public StudentController(ApplicationDbContext context) => _context = context;

        // GET: /Student  — shows list + register form together
        public async Task<IActionResult> Index()
        {
            ViewBag.Students = await _context.Students.OrderBy(s => s.FullName).ToListAsync();
            return View(new Student());
        }

        // POST: /Student/Create
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("FullName,RollNumber,Email,Department,YearOfStudy")] Student student)
        {
            if (ModelState.IsValid)
            {
                _context.Students.Add(student);
                await _context.SaveChangesAsync();
                TempData["Success"] = $"Student '{student.FullName}' registered!";
                return RedirectToAction(nameof(Index));
            }
            ViewBag.Students = await _context.Students.OrderBy(s => s.FullName).ToListAsync();
            TempData["Error"] = "Please fill all required fields correctly.";
            return RedirectToAction(nameof(Index));
        }

        // POST: /Student/Delete
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var s = await _context.Students.FindAsync(id);
            if (s != null) { _context.Students.Remove(s); await _context.SaveChangesAsync(); TempData["Success"] = "Student removed."; }
            return RedirectToAction(nameof(Index));
        }
    }
}
