using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartCampusPortal.Data;
using SmartCampusPortal.Models;

namespace SmartCampusPortal.Controllers
{
    public class ServiceController : Controller
    {
        private readonly ApplicationDbContext _context;
        public ServiceController(ApplicationDbContext context) => _context = context;

        // GET: /Service — shows request form + all requests
        public async Task<IActionResult> Index()
        {
            ViewBag.Students = await _context.Students.OrderBy(s => s.FullName).ToListAsync();
            ViewBag.Services  = await _context.CampusServices.Where(s => s.IsAvailable).OrderBy(s => s.ServiceName).ToListAsync();
            ViewBag.Requests  = await _context.ServiceRequests
                                    .Include(r => r.Student)
                                    .Include(r => r.CampusService)
                                    .OrderByDescending(r => r.RequestedOn)
                                    .ToListAsync();
            return View(new ServiceRequest());
        }

        // POST: /Service/Submit
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Submit([Bind("StudentId,CampusServiceId,Description")] ServiceRequest req)
        {
            if (ModelState.IsValid)
            {
                req.RequestedOn = DateTime.Now;
                req.Status      = RequestStatus.Pending;
                _context.ServiceRequests.Add(req);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Service request submitted!";
                return RedirectToAction(nameof(Index));
            }
            TempData["Error"] = "Please fill all required fields.";
            return RedirectToAction(nameof(Index));
        }

        // POST: /Service/UpdateStatus
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateStatus(int id, RequestStatus status)
        {
            var req = await _context.ServiceRequests.FindAsync(id);
            if (req != null)
            {
                req.Status = status;
                if (status == RequestStatus.Resolved) req.ResolvedOn = DateTime.Now;
                await _context.SaveChangesAsync();
                TempData["Success"] = "Status updated!";
            }
            return RedirectToAction(nameof(Index));
        }

        // POST: /Service/Delete
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var req = await _context.ServiceRequests.FindAsync(id);
            if (req != null) { _context.ServiceRequests.Remove(req); await _context.SaveChangesAsync(); TempData["Success"] = "Request deleted."; }
            return RedirectToAction(nameof(Index));
        }
    }
}
