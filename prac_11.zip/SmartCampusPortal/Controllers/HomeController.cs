using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartCampusPortal.Data;
using SmartCampusPortal.Models;
using System.Diagnostics;

namespace SmartCampusPortal.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;
        public HomeController(ApplicationDbContext context) => _context = context;

        public async Task<IActionResult> Index()
        {
            ViewBag.TotalStudents   = await _context.Students.CountAsync();
            ViewBag.TotalServices   = await _context.CampusServices.CountAsync(s => s.IsAvailable);
            ViewBag.PendingRequests = await _context.ServiceRequests.CountAsync(r => r.Status == RequestStatus.Pending);
            ViewBag.OpenComplaints  = await _context.Complaints.CountAsync(c => c.Status == ComplaintStatus.Open);

            ViewBag.RecentRequests  = await _context.ServiceRequests
                                        .Include(r => r.Student)
                                        .Include(r => r.CampusService)
                                        .OrderByDescending(r => r.RequestedOn)
                                        .Take(5).ToListAsync();

            ViewBag.RecentComplaints = await _context.Complaints
                                        .Include(c => c.Student)
                                        .OrderByDescending(c => c.FiledOn)
                                        .Take(5).ToListAsync();
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error() =>
            View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
