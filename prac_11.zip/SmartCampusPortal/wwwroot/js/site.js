// Smart Campus Portal – Site JS

// Auto-dismiss alerts after 4 seconds
document.addEventListener('DOMContentLoaded', function () {
    setTimeout(function () {
        document.querySelectorAll('.alert-dismissible').forEach(function (el) {
            var alert = bootstrap.Alert.getOrCreateInstance(el);
            alert.close();
        });
    }, 4000);

    // Active nav link highlighting
    var currentPath = window.location.pathname.toLowerCase();
    document.querySelectorAll('.navbar .nav-link').forEach(function (link) {
        if (link.href && link.href !== '#') {
            var url = new URL(link.href);
            if (currentPath.startsWith(url.pathname.toLowerCase()) && url.pathname !== '/') {
                link.classList.add('active');
            }
        }
    });
});

