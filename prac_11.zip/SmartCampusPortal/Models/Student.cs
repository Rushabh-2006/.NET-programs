using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SmartCampusPortal.Models
{
    public class Student
    {
        public int Id { get; set; }

        [Required, StringLength(100)]
        [Display(Name = "Full Name")]
        public string FullName { get; set; } = string.Empty;

        [Required, StringLength(20)]
        [Display(Name = "Roll Number")]
        public string RollNumber { get; set; } = string.Empty;

        [Required, EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Phone]
        [Display(Name = "Phone Number")]
        public string? PhoneNumber { get; set; }

        [Required, StringLength(100)]
        public string Department { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Year of Study")]
        [Range(1, 6)]
        public int YearOfStudy { get; set; }

        [Display(Name = "Enrollment Date")]
        [DataType(DataType.Date)]
        public DateTime EnrollmentDate { get; set; } = DateTime.Now;

        public bool IsActive { get; set; } = true;

        public ICollection<ServiceRequest>? ServiceRequests { get; set; }
        public ICollection<Complaint>? Complaints { get; set; }
    }
}

