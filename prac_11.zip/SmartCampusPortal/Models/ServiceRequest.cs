using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SmartCampusPortal.Models
{
    public enum RequestStatus
    {
        Pending,
        InProgress,
        Resolved,
        Cancelled
    }

    public class ServiceRequest
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Student")]
        public int StudentId { get; set; }

        [ForeignKey("StudentId")]
        public Student? Student { get; set; }

        [Required]
        [Display(Name = "Service")]
        public int CampusServiceId { get; set; }

        [ForeignKey("CampusServiceId")]
        public CampusService? CampusService { get; set; }

        [Required, StringLength(500)]
        public string Description { get; set; } = string.Empty;

        public RequestStatus Status { get; set; } = RequestStatus.Pending;

        [Display(Name = "Requested On")]
        [DataType(DataType.DateTime)]
        public DateTime RequestedOn { get; set; } = DateTime.Now;

        [Display(Name = "Resolved On")]
        [DataType(DataType.DateTime)]
        public DateTime? ResolvedOn { get; set; }

        [StringLength(500)]
        [Display(Name = "Admin Remarks")]
        public string? AdminRemarks { get; set; }
    }
}

