using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SmartCampusPortal.Models
{
    public enum ServiceCategory
    {
        Academic,
        Library,
        Hostel,
        Transport,
        Medical,
        Sports,
        IT,
        Canteen,
        Maintenance
    }

    public class CampusService
    {
        public int Id { get; set; }

        [Required, StringLength(150)]
        [Display(Name = "Service Name")]
        public string ServiceName { get; set; } = string.Empty;

        [StringLength(500)]
        public string? Description { get; set; }

        [Required]
        public ServiceCategory Category { get; set; }

        [Display(Name = "Available")]
        public bool IsAvailable { get; set; } = true;

        [Display(Name = "Contact Email")]
        [EmailAddress]
        public string? ContactEmail { get; set; }

        [Display(Name = "Location / Room")]
        public string? Location { get; set; }

        [Display(Name = "Operating Hours")]
        public string? OperatingHours { get; set; }

        public ICollection<ServiceRequest>? ServiceRequests { get; set; }
    }
}

