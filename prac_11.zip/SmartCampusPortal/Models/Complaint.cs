using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SmartCampusPortal.Models
{
    public enum ComplaintCategory
    {
        Infrastructure,
        Academic,
        Administration,
        Hostel,
        Canteen,
        Transport,
        Other
    }

    public enum ComplaintStatus
    {
        Open,
        UnderReview,
        Resolved,
        Rejected
    }

    public class Complaint
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Student")]
        public int StudentId { get; set; }

        [ForeignKey("StudentId")]
        public Student? Student { get; set; }

        [Required, StringLength(200)]
        public string Title { get; set; } = string.Empty;

        [Required, StringLength(1000)]
        public string Description { get; set; } = string.Empty;

        [Required]
        public ComplaintCategory Category { get; set; }

        public ComplaintStatus Status { get; set; } = ComplaintStatus.Open;

        [Display(Name = "Filed On")]
        [DataType(DataType.DateTime)]
        public DateTime FiledOn { get; set; } = DateTime.Now;

        [Display(Name = "Resolved On")]
        [DataType(DataType.DateTime)]
        public DateTime? ResolvedOn { get; set; }

        [StringLength(500)]
        public string? Resolution { get; set; }

        [Display(Name = "Priority")]
        [Range(1, 5)]
        public int Priority { get; set; } = 3;
    }
}

