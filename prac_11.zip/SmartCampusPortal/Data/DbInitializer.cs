using System;
using System.Linq;
using SmartCampusPortal.Models;

namespace SmartCampusPortal.Data
{
    public static class DbInitializer
    {
        public static void Initialize(ApplicationDbContext context)
        {
            context.Database.EnsureCreated();

            if (!context.Students.Any())
            {
                context.Students.AddRange(
                    new Student { FullName = "Arjun Sharma",  RollNumber = "CS2021001", Email = "arjun@campus.edu",  Department = "Computer Science",    YearOfStudy = 3 },
                    new Student { FullName = "Priya Mehta",   RollNumber = "EC2021002", Email = "priya@campus.edu",  Department = "Electronics",          YearOfStudy = 2 },
                    new Student { FullName = "Rahul Verma",   RollNumber = "ME2021003", Email = "rahul@campus.edu",  Department = "Mechanical",           YearOfStudy = 4 },
                    new Student { FullName = "Sneha Patel",   RollNumber = "CE2022004", Email = "sneha@campus.edu",  Department = "Civil Engineering",    YearOfStudy = 1 },
                    new Student { FullName = "Kiran Kumar",   RollNumber = "CS2020005", Email = "kiran@campus.edu",  Department = "Computer Science",    YearOfStudy = 4 }
                );
                context.SaveChanges();
            }

            if (!context.CampusServices.Any())
            {
                context.CampusServices.AddRange(
                    new CampusService { ServiceName = "Library Book Issue",      Category = ServiceCategory.Library,     Location = "Main Library, Block A",    OperatingHours = "Mon-Sat 8AM-8PM" },
                    new CampusService { ServiceName = "Medical Consultation",    Category = ServiceCategory.Medical,     Location = "Health Center, Block C",   OperatingHours = "Mon-Fri 9AM-5PM" },
                    new CampusService { ServiceName = "Hostel Room Maintenance", Category = ServiceCategory.Hostel,      Location = "Hostel Office",            OperatingHours = "24/7"            },
                    new CampusService { ServiceName = "Bus Pass Application",    Category = ServiceCategory.Transport,   Location = "Admin Block, Room 102",    OperatingHours = "Mon-Fri 10AM-4PM"},
                    new CampusService { ServiceName = "IT / Wi-Fi Support",      Category = ServiceCategory.IT,          Location = "IT Block, Room 201",       OperatingHours = "Mon-Sat 9AM-6PM" },
                    new CampusService { ServiceName = "Sports Equipment Booking",Category = ServiceCategory.Sports,      Location = "Sports Complex",           OperatingHours = "Daily 6AM-10PM"  },
                    new CampusService { ServiceName = "Academic Transcripts",    Category = ServiceCategory.Academic,    Location = "Registrar Office",         OperatingHours = "Mon-Fri 10AM-3PM"}
                );
                context.SaveChanges();
            }

            if (!context.ServiceRequests.Any())
            {
                var students = context.Students.ToList();
                var services = context.CampusServices.ToList();
                context.ServiceRequests.AddRange(
                    new ServiceRequest { StudentId = students[0].Id, CampusServiceId = services[0].Id, Description = "Need 'Clean Code' by Robert Martin",          Status = RequestStatus.Pending     },
                    new ServiceRequest { StudentId = students[1].Id, CampusServiceId = services[1].Id, Description = "Fever and headache since morning",             Status = RequestStatus.Resolved, ResolvedOn = DateTime.Now.AddDays(-1) },
                    new ServiceRequest { StudentId = students[2].Id, CampusServiceId = services[2].Id, Description = "Bathroom tap broken in Room 304",              Status = RequestStatus.InProgress  },
                    new ServiceRequest { StudentId = students[3].Id, CampusServiceId = services[3].Id, Description = "Monthly bus pass – Route 5",                   Status = RequestStatus.Pending     }
                );
                context.SaveChanges();
            }

            if (!context.Complaints.Any())
            {
                var students = context.Students.ToList();
                context.Complaints.AddRange(
                    new Complaint { StudentId = students[0].Id, Title = "Projector not working in Room 203", Description = "Non-functional for 2 weeks.",       Category = ComplaintCategory.Infrastructure, Status = ComplaintStatus.UnderReview },
                    new Complaint { StudentId = students[1].Id, Title = "Canteen food quality degraded",     Description = "Food quality has declined.",        Category = ComplaintCategory.Canteen,        Status = ComplaintStatus.Open        },
                    new Complaint { StudentId = students[2].Id, Title = "Incorrect marks uploaded",          Description = "My MAT301 marks appear incorrect.", Category = ComplaintCategory.Academic,       Status = ComplaintStatus.Resolved, ResolvedOn = DateTime.Now.AddDays(-3) }
                );
                context.SaveChanges();
            }
        }
    }
}
