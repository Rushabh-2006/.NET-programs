using Microsoft.EntityFrameworkCore;
using SmartCampusPortal.Models;

namespace SmartCampusPortal.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Student> Students { get; set; }
        public DbSet<CampusService> CampusServices { get; set; }
        public DbSet<ServiceRequest> ServiceRequests { get; set; }
        public DbSet<Complaint> Complaints { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Student>().HasIndex(s => s.RollNumber).IsUnique();
            modelBuilder.Entity<Student>().HasIndex(s => s.Email).IsUnique();

            modelBuilder.Entity<ServiceRequest>()
                .HasOne(r => r.Student).WithMany(s => s.ServiceRequests)
                .HasForeignKey(r => r.StudentId).OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<ServiceRequest>()
                .HasOne(r => r.CampusService).WithMany(s => s.ServiceRequests)
                .HasForeignKey(r => r.CampusServiceId).OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Complaint>()
                .HasOne(c => c.Student).WithMany(s => s.Complaints)
                .HasForeignKey(c => c.StudentId).OnDelete(DeleteBehavior.Cascade);
        }
    }
}
