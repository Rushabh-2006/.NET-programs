# Smart Campus Service Portal

A clean, simple **4-page ASP.NET Core MVC + SQLite** application built in **C# (.NET 10)** for Visual Studio.

## Pages
1. **Dashboard (`/`)** — Overview stats (Students, Services, Pending Requests, Open Issues) and recent activity.
2. **Students (`/Student`)** — View, register, and remove students on a single page.
3. **Service Requests (`/Service`)** — Submit new service requests, view all requests, update status, or delete.
4. **Complaints (`/Complaint`)** — File complaints, track status, update status, or delete.

## Project Structure
```
SmartCampusPortal/
├── SmartCampusPortal.sln
└── SmartCampusPortal/
    ├── Program.cs
    ├── appsettings.json
    ├── SmartCampusPortal.csproj
    ├── Models/
    │   ├── Student.cs
    │   ├── CampusService.cs
    │   ├── ServiceRequest.cs
    │   ├── Complaint.cs
    │   └── ErrorViewModel.cs
    ├── Data/
    │   ├── ApplicationDbContext.cs
    │   └── DbInitializer.cs
    ├── Controllers/
    │   ├── HomeController.cs
    │   ├── StudentController.cs
    │   ├── ServiceController.cs
    │   └── ComplaintController.cs
    └── Views/
        ├── Home/Index.cshtml
        ├── Student/Index.cshtml
        ├── Service/Index.cshtml
        ├── Complaint/Index.cshtml
        └── Shared/_Layout.cshtml
```

## How to Run in Visual Studio
1. Open `SmartCampusPortal.sln` in Visual Studio 2022.
2. Restore NuGet Packages if prompted.
3. Press **F5** to run.
4. `campus.db` is automatically created and seeded on first launch.
