﻿using System;

namespace ExpenseTracking
{
    class Expense
    {
        private string category;
        private double amount;

        public Expense(string category, double amount)
        {
            this.category = category;
            this.amount = amount;
        }

        public void DisplayExpense()
        {
            Console.WriteLine("Category : " + category);
            Console.WriteLine("Amount   : " + amount);
        }

        // Getter
        public double GetAmount()
        {
            return amount;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            double totalExpense = 0;

            try
            {
                Console.Write("Enter number of expenses: ");
                int n = Convert.ToInt32(Console.ReadLine());

                if (n <= 0)
                {
                    throw new Exception("Number of expenses must be greater than zero.");
                }

                Expense[] expenses = new Expense[n];

                for (int i = 0; i < n; i++)
                {
                    Console.WriteLine("\nExpense " + (i + 1));

                    Console.Write("Enter Category: ");
                    string category = Console.ReadLine();

                    Console.Write("Enter Amount: ");
                    double amount = Convert.ToDouble(Console.ReadLine());

                    if (amount < 0)
                    {
                        throw new Exception("Expense amount cannot be negative.");
                    }

                    expenses[i] = new Expense(category, amount);
                    totalExpense += amount;
                }

                Console.WriteLine("\n===== Expense Details =====");

                foreach (Expense exp in expenses)
                {
                    exp.DisplayExpense();
                    Console.WriteLine("----------------------");
                }

                Console.WriteLine("Total Expense : " + totalExpense);
            }

            catch (FormatException)
            {
                Console.WriteLine("Invalid Input! Please enter numeric values.");
            }

            catch (OverflowException)
            {
                Console.WriteLine("Entered value is too large.");
            }

            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);
            }

            finally
            {
                Console.WriteLine("\nProgram Ended Successfully.");
            }

            Console.ReadKey();
        }
    }
}