﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Practical_10.Models; // Updated to match the folder

namespace Practical_10.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentsController : ControllerBase // Updated to match filename
    {
        private readonly IConfiguration _configuration;

        public StudentsController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        private SqlConnection GetConnection()
        {
            return new SqlConnection(_configuration.GetConnectionString("DefaultConnection"));
        }

        [HttpGet]
        public IActionResult GetStudents()
        {
            List<Student> students = new List<Student>();

            using SqlConnection con = GetConnection();
            string query = "SELECT * FROM Students";
            using SqlCommand cmd = new SqlCommand(query, con);

            con.Open();
            using SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                Student student = new Student()
                {
                    Id = Convert.ToInt32(reader["Id"]),
                    // Safe handling for potential NULL values in the database
                    Name = reader["Name"] == DBNull.Value ? null : reader["Name"].ToString(),
                    Email = reader["Email"].ToString() ?? "",
                    Course = reader["Course"].ToString() ?? ""
                };

                students.Add(student);
            }

            return Ok(students);
        }
    }
}
